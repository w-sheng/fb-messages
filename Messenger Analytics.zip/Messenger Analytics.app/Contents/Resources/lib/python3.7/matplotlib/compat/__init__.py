from matplotlib import cbook


cbook.warn_deprecated("3.3", name=__name__, obj_type="module")
