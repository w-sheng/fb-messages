
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
#
# To compare versions robustly, use `numpy.lib.NumpyVersion`
short_version = '1.16.1'
version = '1.16.1'
full_version = '1.16.1'
git_revision = '685b9ace06f1dc50e2698099d7a2b6a241379318'
release = True

if not release:
    version = full_version
